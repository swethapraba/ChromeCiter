<?php 
	echo _SERVER["SCRIPT_URI"];
?>