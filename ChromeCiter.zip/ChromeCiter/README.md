# ChromeCiter: Our Web App Class Final Project
Our project will build a better citation tool for student use. This tool will be a Google Chrome extension as opposed to a separate website and will integrate all the main tools students use during research projects- a citation generator (both full and in-text citations) and a bibliography compiler in the form of a popup chrome extension.

This project was completed using HTML, CSS, and Javascript along with Chrome APIs like chrome.storage.
